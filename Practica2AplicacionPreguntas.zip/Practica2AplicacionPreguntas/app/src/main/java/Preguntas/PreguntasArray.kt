package Preguntas

import android.media.Image
import androidx.compose.runtime.Composable


data class Preguntas(var preguntas : String, var imagen : Int ,var respuesta: Boolean)